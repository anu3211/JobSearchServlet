package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet3
 */
public class MyServlet3 extends HttpServlet {
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	
		
		List<String> jobList = (List<String>)request.getAttribute("jobList");
		String technologyName = (String)request.getAttribute("technology");
		String cityName = (String)request.getAttribute("city");

		out.print("Tecnology-->> "+technologyName);
		out.print("<br/>");
		out.print("City-->> "+cityName);
		out.print("<br/>");
		out.print("Jobs-->> "+jobList);
		
		
	}

}
