package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet
 */
public class MyServlet extends HttpServlet {
	String technologies[] = {"java","selenium","node.js"};
	   
	String cities[] = {"delhi","noida"};
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		boolean isFound = false;
		boolean isFound2=false;
		// Read the paramater from Index page
		String technology = request.getParameter("technology");
		
		String city = request.getParameter("city");
		
		// code to validate technology 
		for (String tech:technologies) {
			if(technology.equalsIgnoreCase(tech))
			{
				// bind the technology with request scope
				request.setAttribute("technology", technology);
				// response.sendRedirect("MyServlet2"); // new req & resp 
				
			
				isFound = true;
				break;
			}
		}//end for
		
		
		// in case of not validate 
		if(isFound == false)
		{
			out.print("Technology not in the List </br>");
		}
		
		
		for (String cit:cities) {
			if(city.equalsIgnoreCase(cit))
			{
				// bind the technology with request scope
				request.setAttribute("city", city);
				// response.sendRedirect("MyServlet2"); // new req & resp 
				
				
				
				isFound2 = true;
				break;
			}
		}//end for
		
		
		// in case of not validate 
		if(isFound == false || isFound2 == false)
		{
			out.print("City not in the List</br>");
		}
		else {
			request.getRequestDispatcher("MyServlet2").forward(request, response);
		}
		
		ServletContext context = getServletContext();
		String serverLocation = context.getInitParameter("server-location");
		
		ServletConfig config = getServletConfig();
		String devName = config.getInitParameter("Servlet-Developer-Name");
		
		out.println("<b> From Servlet-Context </b> "+serverLocation);
		out.println("<br/><b> From Servlet-Config </b> "+devName);
		
		
	}

}
